class ParseVersionError(ValueError):
    pass


class ParseConstraintError(ValueError):
    pass
